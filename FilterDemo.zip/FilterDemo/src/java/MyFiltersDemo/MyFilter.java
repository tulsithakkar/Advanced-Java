/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MyFiltersDemo;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author NIRALI
 */
public class MyFilter implements Filter{
    FilterConfig config;
    @Override
    public void init(FilterConfig config) throws ServletException {
         this.config = config;
    }

    @Override
    public void doFilter(ServletRequest sr, ServletResponse sr1, FilterChain fc) throws IOException, ServletException {
      PrintWriter out = sr1.getWriter();
                System.out.println("Filter befor serlet");
		String env = config.getInitParameter("KK");

		if (env.equals("Core Java")) {
			out.println("KK Teaches Core Java");
		} 
                else if (env.equals("Advance Java")){
			fc.doFilter(sr, sr1);// forward the request to next resource
		}
                else
                {
                   fc.doFilter(sr, sr1); 
                }  
                  

                 System.out.println("Filter after serlet");
                
    }

    @Override
    public void destroy() {
       
    }
    
}
