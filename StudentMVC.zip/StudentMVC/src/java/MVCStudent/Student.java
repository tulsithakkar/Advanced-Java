/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MVCStudent;
import java.sql.*;
/**
 *
 * @author NIRALI
 */
public class Student {
    ResultSet getStudList()
    {
     Connection con;

     try
       {
        Class.forName("oracle.jdbc.OracleDriver");
        con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","sys");
            
        String query = "select * from student order by SNO";

           Statement stmt=con.createStatement();
           ResultSet rs=stmt.executeQuery(query);
 
           return rs; 
       }
       catch(Exception e) 
       {
         System.out.println(e);
         return null;
       }
   }
 

}
