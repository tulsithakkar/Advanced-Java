
package jdbcdemo;
import java.sql.*;
import java.io.*;

public class DeleteRecord {
    public static void main(String[] args)throws IOException {
        DataInputStream dis = new DataInputStream(System.in);
        System.out.println("Enter sno for deletion");
        int sno = Integer.parseInt(dis.readLine());
        
        Connection con ;
        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","System","sys");
            
            String query = "Delete from student where sno= " + sno;
            
            Statement stmt = con.createStatement();
            
            stmt.executeUpdate(query);
            
            stmt.close();
            con.close();
            
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        System.out.println("Record deleted succesfully");
        
    }
}
