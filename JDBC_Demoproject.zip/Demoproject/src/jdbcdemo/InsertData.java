/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jdbcdemo;
import java.sql.*;
import java.io.*;

public class InsertData {
   public static void main(String[] args) throws IOException {
        System.out.println("JDBC Insert DEMO PROJECT \n");
        
        DataInputStream dis= new DataInputStream(System.in);
                
        System.out.println("Enter rollnumber");
        int Sno = Integer.parseInt(dis.readLine());
        
        System.out.println("Enter name ");
        String Sname = dis.readLine();
        
        System.out.println("Enter age ");
        int Sage = Integer.parseInt(dis.readLine());
        
        Connection con;
        try{
            //Loading drivers
            Class.forName("oracle.jdbc.OracleDriver");
            
            // connection between java app and oracle
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "sys");
            
            //query
           String query = "Insert into student(Sno,Sname,Sage) values("+Sno+",'"+ Sname +"',"+ Sage+")";
         
           
           // create object of stamtment class and call  connection class  create statment method
           Statement stmt = con.createStatement();
           
           //call statement class executequery method
           stmt.executeUpdate(query);
           
           
           // interate loop and display data
           
           
           stmt.close();
           con.close();   
        }
        catch(Exception e)
        {
            System.out.print(e);
        }
        System.out.println("Data inserted ");
        
    }
}
            

