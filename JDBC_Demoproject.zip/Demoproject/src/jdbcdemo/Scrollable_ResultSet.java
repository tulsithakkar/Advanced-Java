/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jdbcdemo;
import java.sql.*;


public class Scrollable_ResultSet {
    public static void main(String[] args) {
        Connection con;
        try{
            Class.forName("oracle.jdbc.OracleDriver");
            
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","sys");
            Statement smt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            
            ResultSet rs = smt.executeQuery("select * from student");
            
            
            System.out.println("First record");
            rs.first();
            System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getInt(3));
            
            System.out.println();
             System.out.println("next record");
            rs.next();
            System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getInt(3));
            
             System.out.println();
             System.out.println("previous record");
            rs.previous();
            System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getInt(3));
            
            System.out.println();
             System.out.println("last record");
            rs.last();
            System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getInt(3));
            
            System.out.println();
             System.out.println("3rd  record");
            rs.absolute(3);
            System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getInt(3));
            
            
            rs.close();
            smt.close();
            con.close();
            
            
        }
        catch(Exception e)
        {
            System.out.print(e);
        }
         
    }
}
