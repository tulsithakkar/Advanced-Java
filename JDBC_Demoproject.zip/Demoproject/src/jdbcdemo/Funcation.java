/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jdbcdemo;

import java.sql.*;
import java.io.*;
public class Funcation {
    public static void main(String[] args) {
        DataInputStream dis = new DataInputStream(System.in);
        Connection con;
        try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
            
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","sys");
            
            CallableStatement cstmt= con.prepareCall("{? = call AddTwoNumbers(?, ?)}");
            
            while(true)
            {
                System.out.println("Enter number 1");
                int num1 = Integer.parseInt(dis.readLine());
                
                System.out.println("Enter number 2");
                int num2 = Integer.parseInt(dis.readLine());
                
                cstmt.registerOutParameter(1, Types.NUMERIC);
               
                cstmt.setInt(2, num1);
                cstmt.setInt(3, num2);
               
                cstmt.execute();

                // Retrieve the result
                int result = cstmt.getInt(1);

                System.out.println("Sum of " + num1 + " and " + num2 + " is: " + result);

            
                System.out.println("do you want to contioue Y/N");
                String op = dis.readLine();
                if(op.equals("N"))
                {
                    break;
                }   
            }
            cstmt.close();
                con.close();
        }catch(Exception e)
        {
            System.out.println(e);
        }
    }
}
