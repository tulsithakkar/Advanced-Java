/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jdbcdemo;

import java.sql.*;
import java.io.*;

public class StoreProcedure {
    public static void main(String[] args) {
        DataInputStream dis = new DataInputStream(System.in);
        
        Connection con;
        try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","sys");
            CallableStatement cstmt = con.prepareCall("{call mypro(?,?,?)}");
            while(true)
            {
            System.out.print("enter sno");
            int sno = Integer.parseInt(dis.readLine());
            cstmt.setInt(1, sno);
            cstmt.registerOutParameter(2, Types.VARCHAR);
            cstmt.registerOutParameter(3, Types.INTEGER);
            
            cstmt.execute();
            
            System.out.println("name is = " + cstmt.getString(2)+ " \nage is =" + cstmt.getInt(3) );
            
            System.out.println("do you want to contioue Y/N");
            String op = dis.readLine();
            if(op.equals("N"))
            {
                break;
            }
            }
            
            cstmt.close();
            con.close();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
   
}
