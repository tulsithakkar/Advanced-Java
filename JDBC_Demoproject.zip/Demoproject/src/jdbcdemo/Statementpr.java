/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jdbcdemo;

import java.sql.*;
import java.io.*;


public class Statementpr {
    public static void main(String[] args) {
        System.out.println("JDBC simple application");
        DataInputStream dis = new DataInputStream(System.in); 
        
        Connection con;
        try
        {
            Class.forName("oracle.jdbc.OracleDriver");
            con= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","sys");
            PreparedStatement psmt = con.prepareCall("delete from student where Sno = ?");
            
            System.out.println("Enter no for delete");
            int no = Integer.parseInt(dis.readLine());
            
            psmt.setInt(1, no);
            psmt.executeUpdate();
            psmt.close();
            con.close();
            System.out.println("deleted");
            
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        
        
        
    }
}
