package jdbcdemo;
import java.sql.*;
import java.io.*;

class opration{
        void selectMethod()
        {
            System.out.println("JDBC DEMO PROJECT \n");
        Connection con;
        try{
            Class.forName("oracle.jdbc.OracleDriver");
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "sys");
           String query = "select * from UserRegistration";
           Statement stmt = con.createStatement();
           ResultSet rs = stmt.executeQuery(query);
           while(rs.next())
           {
               System.out.println(rs.getString("RegistrationNo")+ " " + rs.getString("Username") + " " + 
                       rs.getString("password") + " " + rs.getString("Email"));
           }
           
           rs.close();
           stmt.close();
           con.close();   
        }
        catch(Exception e)
        {
            System.out.print(e);
        }
        }
        
        void insertMethod(int RegistrationNo,String Username,String password,String Email)
        {
          Connection con;
        try{
            //Loading drivers
            Class.forName("oracle.jdbc.OracleDriver");
            
            // connection between java app and oracle
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "sys");
            
            //query
           String query = "Insert into UserRegistration values("+RegistrationNo+",'"+ Username +"','"+ password +"','"+ Email +"')";
           
           // create object of stamtment class and call  connection class  create statment method
           Statement stmt = con.createStatement();
           
           //call statement class executequery method
           stmt.executeUpdate(query);
           
           
          
           
           
           stmt.close();
           con.close();   
        }
        catch(Exception e)
        {
            System.out.print(e);
        }
        System.out.println("Data inserted ");
           
        }
        void updateMethod(int RegistrationNo,String Username,String password,String Email)
        {
            Connection con;
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            
            con= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system", "sys");
            
            String query = "update UserRegistration set Username = '"+ Username + "' ,   password= '" +  password+ "',Email= '" + Email+ 
                    "'where RegistrationNo = " + RegistrationNo;
            
            Statement stmt = con.createStatement();
            stmt.executeUpdate(query);
            
            stmt.close();
            con.close();
           
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        
        System.out.println("Updated succesully");
        
        }
        
        
        void deleteMethod(int RegistrationNo )
        {
            Connection con ;
        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","System","sys");
            
            String query = "Delete from UserRegistration where  RegistrationNo= " +  RegistrationNo;
            Statement stmt = con.createStatement();
            
            stmt.executeUpdate(query);
            
            stmt.close();
            con.close();
            
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        System.out.println("Record deleted succesfully");
         
        }
    }
public class UserRegistration {
    public static void main(String[] args) throws IOException {
     
       opration obj = new opration();
         DataInputStream dis= new DataInputStream(System.in);
        int ch =0;
         do
         {
             System.out.println("Select the opration which you want to perform on database ");
             System.out.println("1. select");
             System.out.println("2. insert");
             System.out.println("3. update");
             System.out.println("4. delete");
               System.out.println("5. Exit\n");
              ch = Integer.parseInt(dis.readLine());
             switch(ch)
             {
                 case 1: obj.selectMethod();
                          System.out.println();  
                            break;
                 case 2 :System.out.println("Enter registation no ");
                           int  RegistrationNo = Integer.parseInt(dis.readLine());  
                        System.out.println("Enter username ");
                        String Username = dis.readLine();
                        System.out.println("Enter password ");
                        String password = dis.readLine();
                        System.out.println("Enter email ");
                        String Email = dis.readLine();
                        obj.insertMethod(RegistrationNo, Username, password, Email);
                        break;
                 case 3: 
                        System.out.println("Enter registation no ");
                         RegistrationNo = Integer.parseInt(dis.readLine());  
                        System.out.println("Enter username ");
                         Username = dis.readLine();
                        System.out.println("Enter password ");
                         password = dis.readLine();
                        System.out.println("Enter email ");
                         Email = dis.readLine();
                        obj.updateMethod(RegistrationNo, Username, password, Email);
                        break;
                 case 4:System.out.println("Enter registation no ");
                         RegistrationNo = Integer.parseInt(dis.readLine());
                         obj.deleteMethod(RegistrationNo);
                         break;
                 case 5: System.out.println("Exit!! ");
                            break;
                 default :System.out.println("Enter from the given options ");
                            break;
                                         
             }
         }while(ch!=5);
    }
}
