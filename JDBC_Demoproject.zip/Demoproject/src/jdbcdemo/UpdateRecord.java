
package jdbcdemo;

import java.sql.*;
import java.io.*;

public class UpdateRecord {
    public static void main(String[] args)throws IOException {
        DataInputStream dis = new DataInputStream(System.in);
        
        System.out.println("Enter sno for updation");
        int sno = Integer.parseInt(dis.readLine());
        
        System.out.println("Enter sname: ");
        String sname = dis.readLine();
        
         System.out.println("Enter sage for updation");
        int sage = Integer.parseInt(dis.readLine());
        
        Connection con;
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            
            con= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system", "sys");
            
            String query = "update student set sname = '"+ sname + "' , sage = " + sage +"where sno = " + sno;
            
            Statement stmt = con.createStatement();
            stmt.executeUpdate(query);
            
            stmt.close();
            con.close();
           
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        
        System.out.println("Updated succesully");
    }
}
