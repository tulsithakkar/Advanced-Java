
// assignment 1 to calculate age of the employee
package jdbcdemo;

import java.sql.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.io.*;

public class Assignment1_CallableFunction {
    public static void main(String[] args) {
      DataInputStream dis = new DataInputStream(System.in);
      Connection con;
        try {
             Class.forName("oracle.jdbc.driver.OracleDriver");     // loading drivers
             con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","sys");
            
           
             //call function
            CallableStatement cstmt = con.prepareCall("{? = call AGE_CALC(?, ?, ?)}");
            
            
            cstmt.registerOutParameter(1, Types.NUMERIC);

            System.out.print("Enter Employee number: ");
            int empno= Integer.parseInt(dis.readLine());
            
            System.out.print("Enter Employee name: ");
            String empname = dis.readLine();
          
            System.out.print("Enter employee Date of Birth (dd/mm/yy): ");
            String dobStr = dis.readLine();

           
            
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yy");
            java.util.Date dob = dateFormat.parse(dobStr);

            cstmt.setDate(2, new java.sql.Date(dob.getTime()));

            cstmt.registerOutParameter(3, Types.NUMERIC);
            cstmt.registerOutParameter(4, Types.NUMERIC);

            cstmt.execute();
            
            int years = cstmt.getInt(1);
            int months = cstmt.getInt(3);
            int days = cstmt.getInt(4);
            
            System.out.println();
            
            System.out.println("employee no:  " + empno );
            System.out.println("employee name:  " + empname );
            System.out.println("employee Age: " + years + " years, " + months + " months, " + days + " days");
            
            cstmt.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
