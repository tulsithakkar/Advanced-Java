/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jdbcdemo;

import java.sql.*;

public class Transaction_Management {
    public static void main(String[] args) throws SQLException {
        Connection con= null;
        Savepoint sp = null;
        Statement smt = null;
        try{
            
            Class.forName("oracle.jdbc.OracleDriver");
            
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","sys");
            con.setAutoCommit(false);
            
             smt = con.createStatement();
            
             sp = con.setSavepoint("sp1");
            
            String query = "insert into student values (112,'nilay',67)";
            
            smt.executeUpdate(query);
            con.commit();
            System.out.println("Transcation commited succesfully");
            
    
        }
        catch(Exception e)
        {
               con.rollback(sp);
                System.out.println("Transcation not commited yet");
        }
        finally{
            smt.close();
            con.close();
            
        }
    }
}
