
package jdbcdemo;
import java.sql.*;
public class Practical_test1 {
    public static void main(String[] args) {
        Connection con;
        try
        {
           Class.forName("oracle.jdbc.driver.OracleDriver");
         con = DriverManager.getConnection("jdc:oracle:thin:@localhost:1521:XE","system","sys");
         
         CallableStatement csmt = con.prepareCall("{call highAge1(?)}");
         csmt.registerOutParameter(1, Types.NUMERIC);
         
         csmt.execute();
         var highage = csmt.getInt(1);
          System.out.println("sage: " + csmt.getInt(1));
         String query = "select * from student where SAGE = " + highage;
         Statement smt= con.createStatement();
         
         ResultSet rs = smt.executeQuery(query);
         
         while (rs.next())
         {
            System.out.println("id: " +  rs.getString("SNO") + "\n name: " + rs.getString("SNAME") + "\nage: " +  rs.getString("SAGE"));
         }
         smt.close();
         csmt.close();
         con.close();
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        
    }
}
