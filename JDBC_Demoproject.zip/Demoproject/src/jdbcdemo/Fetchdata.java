/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jdbcdemo;

import java.sql.*;

public class Fetchdata {
    public static void main(String[] args) {
        
        System.out.println("JDBC DEMO PROJECT \n");
        Connection con;
        try{
            //Loading drivers
            Class.forName("oracle.jdbc.OracleDriver");
            
            // connection between java app and oracle
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "sys");
            
            //query
           String query = "Select * from student";
           
           // create object of stamtment class and call  connection class  create statment method
           Statement stmt = con.createStatement();
           
           //call statement class executequery method
           ResultSet rs = stmt.executeQuery(query);
           
           // interate loop and display data
           
           while(rs.next())
           {
               System.out.println(rs.getString("Sno")+ " " + rs.getString("Sname") + " " + rs.getString("Sage"));
           }
           
           rs.close();
           stmt.close();
           con.close();   
        }
        catch(Exception e)
        {
            System.out.print(e);
        }
    }
}
