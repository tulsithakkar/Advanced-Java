

package jdbcdemo;

import java.sql.*;
import java.io.*;
public class FunctionReverseNumber {
    public static void main(String[] args) {
        DataInputStream dis = new DataInputStream(System.in);
        Connection con;
        
        try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
            
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","sys");
            CallableStatement csmt = con.prepareCall("{ ? = call ReverseNumber(?)}");
            
            while(true)
            {
                System.out.println("Enter number");
                int number1 = Integer.parseInt(dis.readLine());
                        
                csmt.setInt(2, number1);
                csmt.registerOutParameter(1, Types.NUMERIC);
                
                csmt.execute();
                
                System.out.println(number1 + " reverse " + csmt.getInt(1));
                               
                System.out.println("Do you want to contioue Y/N");
                String op = dis.readLine();
                
                if(op.equals("N"))
                {
                    break;
                }
                
            }
            
            csmt.close();
            con.close();    
        }
        catch(Exception e)
        {
            System.out.println(e);
        } 
    }
}
