/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jdbcdemo;

import java.sql.*;
import java.io.*;
public class PrepareStmtUpdate {
    public static void main(String[] args) {
        DataInputStream dis = new DataInputStream(System.in);
        
        Connection con;
        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","sys");
            PreparedStatement psmt = con.prepareCall("update student set sname = ?, sage= ? where sno = ?");
            while(true)
            {
                System.out.println("Enter sno");
                int sno = Integer.parseInt(dis.readLine());
                
                System.out.println("Enter sname");
                String sname = dis.readLine();
                
                System.out.println("Enter sage");
                int sage = Integer.parseInt(dis.readLine());
                
                psmt.setInt(3, sno);
                psmt.setString(1, sname);
                psmt.setInt(2, sage);
                
                int i = psmt.executeUpdate();
                System.out.println(i + "record updated");
                
                System.out.println("Do you want to contioue Y/N");
                var op = dis.readLine();
                if(op.equals("N"))
                {
                    break;
                }  
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        
    }
}
