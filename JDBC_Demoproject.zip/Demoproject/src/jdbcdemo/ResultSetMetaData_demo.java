package jdbcdemo;
import java.sql.*;

public class ResultSetMetaData_demo {
    public static void main(String[] args) {
        Connection con;
        try
        {
            Class.forName("oracle.jdbc.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","sys");
            
            Statement smt = con.createStatement();
            
            ResultSet rs = smt.executeQuery("Select * from student");
            
            ResultSetMetaData rmeta = rs.getMetaData();
            
            System.out.println("column count is " + rmeta.getColumnCount());
            
            for(int i=1; i <= rmeta.getColumnCount(); i++)
            {
                System.out.println();
              System.out.println("Column name is " + rmeta.getColumnName(i));
              System.out.println("Column type is " + rmeta.getColumnTypeName(i));
               System.out.println("Column display size is " + rmeta.getColumnDisplaySize(i));
                 
            }
           // System.out.println("tabel name " + rmeta.getTableName(1));
           
            rs.close();
            smt.close();
            con.close();
        }
        catch(Exception e)
        {
            System.out.print(e);
        }
    }
}
