
package jdbcdemo;

import java.sql.*;
public class PreparestFetch {
    public static void main(String[] args) {
        Connection con;
        try
        {
            Class.forName("oracle.jdbc.OracleDriver");
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","sys");
            String query = "select * from student where Sno= ?";
            
            PreparedStatement psmt = con.prepareStatement(query);
            psmt.setInt(1, 102);
            ResultSet rs = psmt.executeQuery();
            while(rs.next())
            {
                System.out.println(rs.getString("Sno")+" "+ rs.getString("Sname") + " " + rs.getString("Sage"));

            }
            rs.close();
            psmt.close();
            con.close();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        
    }
}
