
package jdbcdemo;
import java.sql.*;
import java.io.*;

public class preparestInsert {
    public static void main(String[] args) throws IOException {
        DataInputStream dis = new DataInputStream(System.in);
        
        Connection con;
        try{
            Class.forName("oracle.jdbc.OracleDriver");
            con= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","sys");
            
            String query= "insert into student values(?,?,?)";
            PreparedStatement psmt= con.prepareStatement(query);
          
            while(true)
            {
                System.out.println("Enetr sno");
                int sno = Integer.parseInt(dis.readLine());
        
                System.out.println("Enter Sname");
                String sname = dis.readLine();
        
                System.out.println("Enter sage");
                int sage = Integer.parseInt(dis.readLine());
        
                   
                   psmt.setInt(1, sno);
                   psmt.setString(2, sname);
                    psmt.setInt(3, sage);
            
                    int i = psmt.executeUpdate();
                    System.out.println(i +"record is inserted");
                    
                    System.out.println("do you want to contioue Y/N");
                    String op = dis.readLine();
                    if(op.equals("N"))
                    {
                        break;
                    }
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        
        
    }
}
