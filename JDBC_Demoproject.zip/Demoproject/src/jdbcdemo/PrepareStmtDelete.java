/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jdbcdemo;
import java.sql.*;
import java.io.*;
public class PrepareStmtDelete {
    public static void main(String[] args) {
        
        DataInputStream dis = new DataInputStream(System.in);
        Connection con;
        try{
              Class.forName("oracle.jdbc.driver.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","System","sys");
            PreparedStatement psmt = con.prepareCall("delete from student where sno = ?");
            
            while(true)
            {
                System.out.println("enter sno");
                int sno = Integer.parseInt(dis.readLine());
                
                psmt.setInt(1, sno);
                int i= psmt.executeUpdate();
                
                System.out.println(i + "Record deleted");
                
                System.out.println("Do you want to continue Y/N");
                var op = dis.readLine();
                if(op.equals("N"))
                {
                    break;
                }
            }
        }
        catch(Exception e)
        {
            System.out.print(e);
        }
    }
}
