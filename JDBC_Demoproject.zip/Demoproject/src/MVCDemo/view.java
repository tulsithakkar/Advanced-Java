/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MVCDemo;


public class view {
    public void disEmpinfo(int eid,String empname )
    {
        System.out.println("Employee information");
        System.out.println("Employee id: " + eid);
        System.out.println("Employee Name: " + empname);
    }
}
