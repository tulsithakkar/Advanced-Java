
package MVCDemo;


public class MVC1 {
    public static void main(String[] args) {
        model m1 = new model();
        view v1 = new view();
        controller c1 = new controller(m1,v1);
        
        m1.empid= 1;
        m1.empName="Tulsi";
        
        c1.updatedata();
        
         m1.empid= 2;
        m1.empName="Jayesh";
        
        c1.updatedata();
    }
}
