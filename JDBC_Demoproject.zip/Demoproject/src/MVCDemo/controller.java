/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MVCDemo;


public class controller {
    private model m1;
    private view v1;

    public controller(model m1, view v1) {
        this.m1 = m1;
        this.v1 = v1;
    }
    public void updatedata()
    {
       v1.disEmpinfo(m1.getEmpid(), m1.getEmpName());
    }
}
