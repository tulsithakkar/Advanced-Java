/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package CRUD_OP;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

public class LoginValidation_student extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        PrintWriter out= resp.getWriter();
        
        String uname = req.getParameter("uname");
        String password = req.getParameter("Password");
        
        Connection con;
        try
        {

           
           Class.forName("oracle.jdbc.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","sys");
            
           String query = "select SNAME,PASSWORD FROM STUDENT";
           
           Statement smt= con.createStatement();
           
           ResultSet rs= smt.executeQuery(query);
           int result =0;
           
           while(rs.next())
           {
               if(rs.getString("SNAME").equals(uname) && rs.getString("PASSWORD").equals(password))
               {
                    result=1;
                    RequestDispatcher RD = req.getRequestDispatcher("list");
                    RD.forward(req, resp);  
                    
               }
           }
           if(result ==0)
           {
               
                  
                      out.println("<b> Sorry, your UserName or password is Incorrect!!");
                RequestDispatcher RD = req.getRequestDispatcher("LoginFrom_Student");
                RD.include(req, resp);
           }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        
        
    }

    

}
