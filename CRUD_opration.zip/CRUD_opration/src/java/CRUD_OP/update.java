/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package CRUD_OP;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

public class update extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        
        String sno = req.getParameter("SNO");
        String sname = "";
        int sage=0;
        String password = "";
        Connection con = null;
        try{
          Class.forName("oracle.jdbc.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","sys");
            Statement smt= con.createStatement();
            String query = "select * from student where SNO="+sno;
            ResultSet rs= smt.executeQuery(query);
            while(rs.next())
            {
             sname= rs.getString("SNAME");
             sage= rs.getInt("SAGE");
          
            }
            rs.close();
            smt.close();
            con.close();
            System.out.println("SNAME");
        
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        
        out.println("<html>");
        out.println("<body bgcolor='LightSkyBlue'>");
        out.println("<center>Update Student Data</center>");
        out.println("<form action='edit'>");
        out.println("<table border='1' align='center' bgcolor='cyan'>");
       out.println("<tr><td>SNO:<input type='text' name='sno' value=' "+sno+"' readonly></td></tr>");
         
          out.println("<tr><td>SName:<input type='text' name='sname' value= "+sname+"></td></tr>");
            out.println("<tr><td>Sage:<input type='text' name='sage' value= "+sage+"></td></tr>");
              
              out.println("<tr><td colspan='2'><input type='submit' value='submit'></td></tr>");
        out.println("</table>");
        out.println("</body>");
        out.println("</html>");
        
        

    }   
}
