
package CRUD_OP;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

public class list extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       resp.setContentType("text/html");
       PrintWriter out = resp.getWriter();
       
       out.println("<html>");
       out.println("<body bgcolor= 'cyan'>");
       out.println("<center><h1>CRUD opration on student table </h1></center>");

         Connection con = null;
       try
       {
        
              Class.forName("oracle.jdbc.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","sys");
            
            String query = "select * from student order by SNO";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            
            out.println("<table border='1',  align='center'>");
            out.println("<tr>");
            out.println("<th>Student SNO</th>");
            out.println("<th>Student SName</th>");
            out.println("<th>Student Sage</th>");
          
            out.println("<th>Update</th>");
            out.println("<th>Delete</th>");
            out.println("</tr>");
            
            while(rs.next())
            {
                 out.println("<tr>");
                 out.println("<td>"+rs.getString("SNO") +"</td>");
                 out.println("<td>"+rs.getString("SNAME") +"</td>");
                out.println("<td>"+rs.getString("SAGE") +"</td>");
                
                out.println("<td> <a href = 'update?SNO=" + rs.getString("SNO") + "'>Update</a></td>");
                out.println("<td> <a href = 'delete?SNO=" + rs.getString("SNO") + "' > Delete </a> </td>");
                out.println("</tr>");
            }
            out.println("</table>");
            out.println("<br><center> <a href='ADD'>Add new Student</a></center>");
            rs.close();
            stmt.close();
            con.close();       
       }
       catch(Exception e)
       {
           System.out.println(e);
       }
       out.println("</body>");
       out.println("</html>");
    }
}
