
package BOOK_OP;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class BOOK_BILL extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
          resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        
        
        String name = req.getParameter("name");
        String price = req.getParameter("price");
        String qun = req.getParameter("qun");
        
        int total = Integer.parseInt(price) * Integer.parseInt(qun);
        out.println("<html>");
        out.println("<body bgcolor='LightSkyBlue'>");
        out.println("<center><b>Book Bill</b>");
        
        out.println("<br> Book name = "+ name );
        out.println("<br>Book price = "+ price );
        out.println("<br> Book quantity = "+ qun );
        out.println("<br>Total = "+ total);
        out.println("</center>");
        out.println("</body>");
        out.println("</html>");
                
    }
 
}
