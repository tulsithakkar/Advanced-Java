/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package BOOK_OP;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

public class Purchase_Book extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        
        String id = req.getParameter("ID");
        String name = "";
        int price = 0;
        
        Connection con = null;
        try{
          Class.forName("oracle.jdbc.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","sys");
            Statement smt= con.createStatement();
            String query = "select * from BOOK where ID="+ id;
            ResultSet rs= smt.executeQuery(query);
            while(rs.next())
            {
             name= rs.getString("NAME");
             price= rs.getInt("PRICE");
             
            }
            rs.close();
            smt.close();
            con.close();
            
            out.println("<html>");
        out.println("<body bgcolor='LightSkyBlue'>");
        out.println("<center>Purchase Book</center>");
        out.println("<form action='BOOK_BILL'>");
        out.println("<table border='1' align='center' bgcolor='cyan'>");
      
         
          out.println("<tr><td>Book name:<input type='text' name='name' value= "+name+"></td></tr>");
            out.println("<tr><td>Book price<input type='text' name='price' value= "+price+"></td></tr>");
               out.println("<tr><td>Book quantity:<input type='text' name='qun'></td></tr>");
              out.println("<tr><td colspan='2'><input type='submit' value='submit'></td></tr>");
        out.println("</table>");
        out.println("</body>");
        out.println("</html>");
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

   
}
