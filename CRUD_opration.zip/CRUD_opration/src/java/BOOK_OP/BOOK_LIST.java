/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package BOOK_OP;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

public class BOOK_LIST extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       resp.setContentType("text/html");
       PrintWriter out = resp.getWriter();
       
       Connection con =null;
       try
       {
           Class.forName("oracle.jdbc.OracleDriver");
           con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","sys");
           String query = "select * from BOOK ORDER BY ID";
           Statement stmt = con.createStatement();
           ResultSet rs = stmt.executeQuery(query);
           
           out.println("<html>");
           out.println("<body bgcolor='yellow'>");
           out.println("<center>");
           out.println("<br>Book list<br>");
           
           out.println("<table border='1' align='center' >");
           out.println("<tr >");
           out.println(" <th>Book id </th>");
           out.println("<th> Book name </th>");
           out.println("<th> Book price </th>");
           out.println("<th> Purchase book  </th>");
            out.println("</tr>");
           
            while(rs.next())
            {
                  out.println("<tr >");
                  out.println(" <td>" + rs.getString("ID") +" </td>");
                  out.println(" <td>" + rs.getString("NAME") +" </td>");
                  out.println(" <td>" + rs.getString("PRICE") +" </td>");
                  out.println("<td> <a href = 'Purchase_Book?ID=" + rs.getString("ID") + "'>Purchase Book </a></td>");
                 
                    out.println("</tr>"); 
            }
            
           out.println("<html>");
           out.println("</table>");
           
           out.println("<br> <br> <a href='ADD_BOOK'> Add new Book </a>");
           
           out.println("</center>");
           out.println("</body>");
           out.println("</html>");
           
        rs.close();
        stmt.close();
        con.close();
       }
       catch(Exception e)
       {
        System.out.println(e);
       }
       
       
    }
}
