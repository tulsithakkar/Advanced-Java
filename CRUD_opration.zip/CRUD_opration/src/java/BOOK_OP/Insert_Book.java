/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package BOOK_OP;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

public class Insert_Book extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
               resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        
        String id = req.getParameter("id");
        String name = req.getParameter("name");
        String price = req.getParameter("Price");
      
        
        
        Connection con = null;
        try{
            Class.forName("oracle.jdbc.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","sys");
            Statement stmt = con.createStatement();
            String query ="insert into BOOK values("+id+ ",'"+name+"',"+price+ ")";
            stmt.executeUpdate(query);
            stmt.close();
            con.close();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        resp.sendRedirect("BOOK_LIST");  
    }

}
