/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package BOOK_OP;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;


public class ADD_BOOK extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
          resp.setContentType("text/html");
       PrintWriter out = resp.getWriter();
       
       Connection con =null;
       int ID=0;
       try
       {
           Class.forName("oracle.jdbc.OracleDriver");
           con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","sys");
           String query = "select max(ID) MID from BOOK ORDER BY ID";
           Statement stmt = con.createStatement();
           ResultSet rs = stmt.executeQuery(query);
           while(rs.next())
            {
                ID = rs.getInt("MID");
            }
            rs.close();
            stmt.close();
            con.close();
       }
       catch(Exception e)
       {
           System.out.println(e);
       }
       ID++;
            out.println("<html>");
            out.println("<body bgcolor='LightSkyBlue'>");
            out.println("<center><h1>Insert book <h1> <Center>");
            out.println("<form action='Insert_Book'>");
            
            out.println("<table border = '1' align='center' bgcolor='yellow' >");
            out.println("<tr><td>Book id: <input type='text' name='id' value=' "+ ID + "'readonly></td></tr>");
            out.println("<tr><td>Book Name: <input type='text' name='name' ></td></tr>");
            out.println("<tr><td>Book Price: <input type='text' name='Price' ></td></tr>");
              
             out.println("<tr><td> <input type='submit' value='submit' ></td></tr>");
            out.println("</table>");
            out.println("</form>");
            out.println("</body>");
            out.println("</html>");
       
       
       
       
       
    }

    
}
