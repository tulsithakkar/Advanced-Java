/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package STUDENT_OP;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

public class ADD_STUDENT extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        Connection con = null;
             int ID=0;
       try
       {
            Class.forName("oracle.jdbc.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","sys");
            
            String Query="Select max(ID) maxnum from student1";
            
            Statement smt = con.createStatement();
            ResultSet rs= smt.executeQuery(Query);
      
            while(rs.next())
            {
                ID = rs.getInt("maxnum");
            }
            rs.close();
            smt.close();
            con.close();
       }
       catch(Exception e)
       {
           System.out.println(e);
       }
       ID++;
            out.println("<html>");
            out.println("<body bgcolor='LightSkyBlue'>");
            out.println("<center><h1>Insert Student <h1> <Center>");
            out.println("<form action='INSERT_STUDENT'>");
            
            out.println("<table border = '1' align='center' bgcolor='yellow' >");
            out.println("<tr><td>Student ID: <input type='text' name='ID' value=' "+ ID + "'readonly></td></tr>");
            out.println("<tr><td>Student Name: <input type='text' name='Name' ></td></tr>");
            out.println("<tr><td>Student MARKS1: <input type='text' name='M1' ></td></tr>");
            out.println("<tr><td>Student MARKS1: <input type='text' name='M2' ></td></tr>");
            out.println("<tr><td>Student MARKS1: <input type='text' name='M3' ></td></tr>");
              
             out.println("<tr><td> <input type='submit' value='submit' ></td></tr>");
            out.println("</table>");
            out.println("</form>");
            out.println("</body>");
            out.println("</html>");
    }

  
    

   
}
