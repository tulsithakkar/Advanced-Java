/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package STUDENT_OP;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;


public class CAL_TOTAL extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
         resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        
         String id = req.getParameter("ID");
         
         String name = "";
        int m1=0;
        int m2=0;
        int m3=0;
        int total=0;
                
        
        
        Connection con = null;
        try{
          Class.forName("oracle.jdbc.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","sys");
            Statement smt= con.createStatement();
            String query = "select * from student1 where ID="+ id;
            ResultSet rs= smt.executeQuery(query);
            while(rs.next())
            {
             
             name= rs.getString("NAME");
             m1= rs.getInt("MARK1");
             m2= rs.getInt("MARK2");
             m3= rs.getInt("MARK3");
            
            }
            rs.close();
            smt.close();
            con.close();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
         
         
        total = m1+m2+m3; 
         
         
      
        out.println("<html>");
        out.println("<body bgcolor='LightSkyBlue'>");
        out.println("<center><b>Book Bill</b><br>");
        
        out.println("<br> Student id = "+ id );
        out.println("<br> student name = "+ name );
        out.println("<br> mark1 = "+ m1 );
       out.println("<br> mark2 = "+ m2 );
       out.println("<br> mark3 = "+ m3 );
        
        out.println("<br>Total = "+ total);
        out.println("</center>");
        out.println("</body>");
        out.println("</html>");
    }

    
}
