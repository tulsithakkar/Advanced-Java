/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package SessionTrackingDemo;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class Check1 extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
          resp.setContentType("text/html");
       PrintWriter out = resp.getWriter();
       
       out.println("<html>");
        out.println("<body bgcolor='yellow'>");
        out.println("<center>");
             String uname= req.getParameter("uname");
            String pass= req.getParameter("pass");
             String op= req.getParameter("gen");
        if(op.equals("Male"))
        {
            resp.sendRedirect("Male?user=" + uname+ "&pwd="+pass);       
        }
        else
        {
           resp.sendRedirect("FeMale?user=" + uname+ "&pwd="+pass);   
        }
        
         out.println("</center>");
         out.println("</body>");
         out.println("<html>");
    }

  
   

    
}
