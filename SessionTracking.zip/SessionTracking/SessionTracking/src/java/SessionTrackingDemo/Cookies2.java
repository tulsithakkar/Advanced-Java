/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package SessionTrackingDemo;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class Cookies2 extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
      resp.setContentType("text/html");
      PrintWriter out = resp.getWriter();
      
      String uname = req.getParameter("uname");
      String pass = req.getParameter("pass");
      
       out.println("<html>");
       out.println("<body bgcolor='cycn'>");
       out.println("Welcome " + uname);
       Cookie c1 = new Cookie("User",uname);
       Cookie c2 = new Cookie("pass", pass);
       resp.addCookie(c1);
       resp.addCookie(c2);
       
       
       out.println("<Form action='Cookies3'>");
       
       out.println("<br> <input type='submit' value='submit'>");
       out.println("</Form>");
       out.println("<body>");
       out.println("<html>");
            
      
      
      
      
      
      
      
      
      
      
    }

    
}
