/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package SessionTrackingDemo;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class UserForm extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
       PrintWriter out = resp.getWriter();
       
       out.println("<html>");
        out.println("<body bgcolor='yellow'>");
        out.println("<center>");
         out.println("<Form action='Check1'>");
         out.println("<br>");
         out.println("User Name: <input type='text' name='uname'><br><br>");
            out.println("Password: <input type='password' name='pass'><br><br>");
             out.println("Gender: <input type='Radio' name='gen' value='Male'> Male ");
            
              out.println("<input type='Radio' name='gen' value='FeMale'> Female <br> ");
            
             out.println("<br>");
          out.println("<Input type='submit' value='submit'>");
         out.println("</Form>");
            out.println("</center>");
         out.println("</body>");
          out.println("<html>");
    }

   
}
