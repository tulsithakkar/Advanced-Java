/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package SessionTrackingDemo;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;

public class session2 extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        
        String name = req.getParameter("uname");
        String pass = req.getParameter("pass");
        out.println("<html>");
        out.println("<body>");
        out.println("<form action='session3'>");
      
        HttpSession session =req.getSession();
        session.setAttribute("uid", name);
        session.setAttribute("pass", pass);
        
        
        
        out.println("<input type='submit' value='submit'>");
        out.println("</form>");
        out.println("</body>");
        out.println("</html>");
    }

   
}
