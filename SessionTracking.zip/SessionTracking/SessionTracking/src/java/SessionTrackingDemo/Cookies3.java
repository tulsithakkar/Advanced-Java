/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package SessionTrackingDemo;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class Cookies3 extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        out.println("<html>");
        out.println("<body bgcolor ='orange'>");
        Cookie arr[] = req.getCookies();   
        for(int i=0; i< arr.length; i++)
        {
         if(arr[i].getName().equals("User"))
         {
           out.println("Welcome" + arr[i].getName() + ":" + arr[i].getValue() + "<br>");  
         }
            
        }
        out.println("<form action='Cookies4'>");
        out.println("<input type='submit' value='Submit'><br>");
        out.println("</form>"); 
        
    }
}
